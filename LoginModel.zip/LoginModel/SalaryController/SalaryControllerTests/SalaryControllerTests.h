//
//  SalaryControllerTests.h
//  SalaryControllerTests
//
//  Created by freedom passion on 19/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface SalaryControllerTests : SenTestCase

@end
