//
//  MainViewController.h
//  SalaryController
//
//  Created by freedom passion on 19/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "FlipsideViewController.h"
#import "LoginViewController.h"
@interface MainViewController : UIViewController <FlipsideViewControllerDelegate>{
    
    
    LoginViewController *controller;
    
}
@property(nonatomic,retain)LoginViewController *controller;
- (IBAction)showInfo:(id)sender;
-(void)nextvieWctR;
@end
