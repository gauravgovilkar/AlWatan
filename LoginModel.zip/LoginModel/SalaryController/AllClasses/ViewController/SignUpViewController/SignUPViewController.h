//
//  SignUPViewController.h
//  SalaryController
//
//  Created by freedom passion on 19/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DatabaseBean.h"
#import "DAL.h"
@interface SignUPViewController : UIViewController<UITextFieldDelegate,UIAlertViewDelegate>{
    
    IBOutlet UITextField *emailTxtField;
    IBOutlet UITextField *userNmTxtField;
    IBOutlet UITextField *passWordTxtField;
    DatabaseBean *databaseBean;
    DAL *dt;
    
}
@property(nonatomic,retain)DatabaseBean *databaseBean;
@property(nonatomic,retain)DAL *dt;
- (BOOL)validateEmail:(NSString *)inputText ;
@end
