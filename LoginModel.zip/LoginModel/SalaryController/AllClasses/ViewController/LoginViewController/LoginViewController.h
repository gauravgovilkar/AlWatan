//
//  MenuViewController.h
//  SalaryController
//
//  Created by freedom passion on 19/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DAL.h"
@interface LoginViewController : UIViewController<UITextFieldDelegate,UIAlertViewDelegate>{
    
    
    IBOutlet UITextField *_userNameTextField;
    IBOutlet UITextField *_passWordTextField;
    DAL *dt;
    
}
@property(nonatomic,retain)DAL *dt;
@end
