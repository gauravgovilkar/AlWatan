//
//  MenuViewController.m
//  SalaryController
//
//  Created by freedom passion on 19/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "LoginViewController.h"
#import "SignUPViewController.h"
#import "AlertManger.h"
#import "MenuViewController.h"
@implementation LoginViewController

@synthesize dt;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    if (dt!=nil) {
        dt=nil;
        [dt release];
    }
    dt=[[DAL alloc] init];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}



#pragma mark UIView & UITextField Delegate Methods


- (BOOL) textFieldShouldReturn:(UITextField*) textField {
	[_userNameTextField resignFirstResponder];
    [_passWordTextField resignFirstResponder];
	return TRUE;
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    NSLog(@"Touch Detected");
    [_userNameTextField resignFirstResponder];
    [_passWordTextField resignFirstResponder];
    
}

-(IBAction)signUpVcTr:(id)sender{
    
    if (_userNameTextField.text!=nil) {
        _userNameTextField.text=nil;
    }
    
    if(_passWordTextField.text!=nil){
    
        _passWordTextField.text=nil;
    }
    
    
    SignUPViewController *controller=[[SignUPViewController alloc] initWithNibName:@"SignUPViewController" bundle:[NSBundle mainBundle]];
    controller.modalTransitionStyle=UIModalTransitionStyleCrossDissolve;
    [self presentModalViewController:controller animated:YES];
    [controller release];
    
    
}

-(IBAction)loginViewController:(id)sender{
    
    if ([dt isLogin:_userNameTextField.text password:_passWordTextField.text]) {
        
        
        [[AlertManger defaultAgent]showAlertForDelegateWithTitle:APP_NAME message:@"Login Successfull" cancelButtonTitle:@"Ok" okButtonTitle:nil parentController:self];
        
    }else{
        
        _userNameTextField.text=nil;
        _passWordTextField.text=nil;
        
        [[AlertManger defaultAgent]showAlertWithTitle:APP_NAME message:@"Please enter valid Username & Password" cancelButtonTitle:@"Ok"];
        
    }
    
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    if (buttonIndex==0) {
        
        MenuViewController *controller=[[MenuViewController alloc] initWithNibName:@"MenuViewController" bundle:[NSBundle mainBundle]];
        controller.modalTransitionStyle=UIModalTransitionStyleCrossDissolve;
        [self presentModalViewController:controller animated:YES];
        [controller release];
       
        
        
    }
    
}




@end
