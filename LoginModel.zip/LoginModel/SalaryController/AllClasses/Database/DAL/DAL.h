#import <UIKit/UIKit.h>
#import "/usr/include/sqlite3.h"
#define dbName @"SalaryDatabase.sqlite"
#import "DatabaseBean.h"
//#import "CacheManager.h"
@interface DAL : NSObject {
	sqlite3		*database;
	NSString	*databasePath;
	//CacheManager *_cMgr;
    DatabaseBean *_dataObj;
}
@property(nonatomic,retain)DatabaseBean *_dataObj;
+ (DAL *)				getInstance;
- (void)				openCreateDatabase;
- (void)				createEditableCopyOfDatabaseIfNeeded;
- (NSString *)			dataFilePath;
//- (BOOL)				insertRecord:(ArticleDesc *)dataObj;
//- (NSMutableArray *)	getAllRecord;	
//- (BOOL)				deleteRecord:(int)recordNo;
//- (BOOL)				isRecordExist:(NSString *)_articleId;

-(BOOL)insertRecord:(DatabaseBean *)dataObj;
- (BOOL) isRecordExistinDataDetailTbl:(NSString *)emailId;
- (BOOL) isLogin:(NSString *)_userId password:(NSString *)password;
@end
