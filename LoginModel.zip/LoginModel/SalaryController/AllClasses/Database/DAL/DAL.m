
#import "DAL.h"

@implementation DAL
@synthesize _dataObj;
+ (DAL *) getInstance{
	@try{
		static DAL *instance;
		if(instance == nil) {
			instance = [[DAL alloc] init];
		
		}
		return instance;
	}@catch (NSException *e) {
		NSLog(@"%@",[e description]);
		[e release];
	}
	return nil;
}
//- (BOOL)				insertRecord:(ArticleDesc *)dataObj{
//	@try{
//		sqlite3_stmt *stmt;
//		const char *query = "insert into article_table (articleId,articleTitle,articleDesc,articleAuthor,articlePostDate,articleImage,smallAdImage,fullAdImage,globleAdImage) values(?,?,?,?,?,?,?,?,?)";
//		
//		if (sqlite3_prepare_v2(database, query, -1, &stmt, NULL) == SQLITE_OK &&
//			sqlite3_bind_text(stmt, 1, [[dataObj articleId] UTF8String], -1, NULL) == SQLITE_OK &&
//			sqlite3_bind_text(stmt, 2, [[dataObj articleTitle] UTF8String], -1, NULL) == SQLITE_OK && 
//			sqlite3_bind_text(stmt, 3, [[dataObj articleDesc] UTF8String], -1, NULL) == SQLITE_OK &&
//			sqlite3_bind_text(stmt, 4, [[dataObj articleAuthor] UTF8String], -1, NULL) == SQLITE_OK &&
//			sqlite3_bind_text(stmt, 5, [[dataObj articlePostDate] UTF8String], -1, NULL) == SQLITE_OK &&
//			sqlite3_bind_blob(stmt, 6, [[dataObj imgDataArticle] bytes], [[dataObj imgDataArticle] length], NULL)== SQLITE_OK &&
//			sqlite3_bind_blob(stmt, 7, [[dataObj imgDataSmallAd] bytes], [[dataObj imgDataSmallAd] length], NULL)== SQLITE_OK &&
//			sqlite3_bind_blob(stmt, 8, [[dataObj imgDataFullAd] bytes], [[dataObj imgDataFullAd] length], NULL)== SQLITE_OK &&
//			sqlite3_bind_blob(stmt, 9, [[dataObj imgDataGlobalAd] bytes], [[dataObj imgDataGlobalAd] length], NULL)== SQLITE_OK) {
//
//			int ret = sqlite3_step(stmt);
//			if (ret == SQLITE_DONE) {
//				sqlite3_finalize(stmt);
//				NSLog(@"Done successfully");
//				sqlite3_close(database); 
//				[dataObj release];
//				return YES;
//			}
//		}
//	}@catch(NSException *e){
//		sqlite3_close(database); 
//		[dataObj release]; 
//		NSLog(@"%@",[e description]);
//		NSLog(@"Error");
//	}
//	sqlite3_close(database); 
//	[dataObj release];
//	return NO;	
//	
//}
//- (NSMutableArray *)	getAllRecord{
//	@try{
//		sqlite3_stmt *statement;
//		
//		ArticleDesc *dataObj;
//		NSMutableArray *array=[[NSMutableArray alloc] init];
//		//NSString *str=@"SELECT articleId,articleTitle,articleDesc,articleAuthor,articlePostDate,articleImage,smallAdImage,fullAdImage,globleAdImage,recNo FROM article_table ORDER BY recNo DESC";
//		const char *sqlStatement ="SELECT articleId,articleTitle,articleDesc,articleAuthor,articlePostDate,articleImage,smallAdImage,fullAdImage,globleAdImage,recNo FROM article_table ORDER BY recNo DESC";
//
//		if(sqlite3_prepare_v2(database, sqlStatement, -1, &statement, nil)==SQLITE_OK){
//			while(sqlite3_step(statement) == SQLITE_ROW)
//			{
//				dataObj=[[ArticleDesc alloc] init];
//				if((char *)sqlite3_column_text(statement, 0)!=NULL || (char *)sqlite3_column_text(statement, 0)!=nil)
//					[dataObj setArticleId:[[NSString alloc] initWithUTF8String: (char *)sqlite3_column_text(statement, 0)]];
//				if((char *)sqlite3_column_text(statement, 1)!=NULL || (char *)sqlite3_column_text(statement, 1)!=nil)
//					[dataObj setArticleTitle:[[NSString alloc] initWithUTF8String: (char *)sqlite3_column_text(statement, 1)]];
//				if((char *)sqlite3_column_text(statement, 2)!=NULL || (char *)sqlite3_column_text(statement, 2)!=nil)
//					[dataObj setArticleDesc:[[NSString alloc] initWithUTF8String: (char *)sqlite3_column_text(statement, 2)]];
//				if((char *)sqlite3_column_text(statement, 3)!=NULL || (char *)sqlite3_column_text(statement, 3)!=nil)
//					[dataObj setArticleAuthor:[[NSString alloc] initWithUTF8String: (char *)sqlite3_column_text(statement, 3)]];
//				if((char *)sqlite3_column_text(statement, 4)!=NULL || (char *)sqlite3_column_text(statement, 4)!=nil)
//					[dataObj setArticlePostDate:[[NSString alloc] initWithUTF8String: (char *)sqlite3_column_text(statement, 4)]];
//				[dataObj setImgDataArticle:[[NSData alloc] initWithBytes:sqlite3_column_blob(statement, 5) length:sqlite3_column_bytes(statement, 5)]];
//				[dataObj setImgDataSmallAd:[[NSData alloc] initWithBytes:sqlite3_column_blob(statement, 6) length:sqlite3_column_bytes(statement, 6)]];
//				[dataObj setImgDataFullAd:[[NSData alloc] initWithBytes:sqlite3_column_blob(statement, 7) length:sqlite3_column_bytes(statement, 7)]];
//				[[CacheManager sharedCacheManager] setImgDataGlobalAd:[[NSData alloc] initWithBytes:sqlite3_column_blob(statement, 8) length:sqlite3_column_bytes(statement, 8)]];
//				//NSLog(@"Article: %@ | %@ | %@",[[CacheManager sharedCacheManager] imgDataGlobalAd],[dataObj imgDataArticle],[dataObj imgDataSmallAd]);
//				[dataObj setRecNo: sqlite3_column_int(statement, 9)];
//				[array addObject:dataObj];
//				[dataObj release];
//			}
//		}
//		sqlite3_close(database); 
//		return array;
//	}@catch (NSException *e) {
//		sqlite3_close(database); 
//		NSLog(@"%@",[e description]);
//		[e release];
//	}
//	//sqlite3_close(database); 
//	return nil;	
//	
//}
//- (BOOL)	deleteRecord:(int)recordNo{
//	@try{
//		sqlite3_stmt *stmt=nil;
//		if(stmt==nil){
//			const char *query = "delete from article_table where recNo=?";
//			if(sqlite3_prepare_v2(database, query, -1, &stmt, NULL) == SQLITE_OK){
//				sqlite3_bind_int(stmt, 1, recordNo);
//				if (SQLITE_DONE != sqlite3_step(stmt)){
//					NSAssert1(0, @"Error while deleting. '%s'", sqlite3_errmsg(database));
//					sqlite3_reset(stmt);
//					return NO;
//				}
//				return YES;
//				sqlite3_reset(stmt);
//			}else{
//				return NO;
//			}
//		}else{
//			return NO;
//		}
//	}@catch(NSException *e){
//		sqlite3_close(database); 
//		NSLog(@"%@",[e description]);
//		NSLog(@"Error");
//	}
//	return NO;	
//	
//}



- (BOOL) isLogin:(NSString *)_userId password:(NSString *)password{
	BOOL flag=NO;
	@try{
		sqlite3_stmt *statement;
		
		const char *sqlStatement =[[NSString stringWithFormat:@"SELECT *FROM LoginTable WHERE username='%@' and password='%@'",_userId,password] cStringUsingEncoding:NSUTF8StringEncoding];
        
		[self openCreateDatabase];
		sqlite3_prepare_v2(database, sqlStatement, -1, &statement, nil);
		
		while(sqlite3_step(statement) == SQLITE_ROW)
		{
			flag=YES;
		}
		sqlite3_close(database); 
		return flag;
	}@catch (NSException *e) {
		sqlite3_close(database); 
		NSLog(@"%@",[e description]);
		[e release];
		return flag;	
	}
	//sqlite3_close(database); 
	return flag;	
	
}





- (BOOL) isRecordExistinDataDetailTbl:(NSString *)_categoryId{
	BOOL flag=NO;
	@try{
		sqlite3_stmt *statement;
		
		const char *sqlStatement =[[NSString stringWithFormat:@"SELECT *FROM LoginTable WHERE email= '%@'",_categoryId] cStringUsingEncoding:NSUTF8StringEncoding];

		[self openCreateDatabase];
		sqlite3_prepare_v2(database, sqlStatement, -1, &statement, nil);
		
		while(sqlite3_step(statement) == SQLITE_ROW)
		{
			flag=YES;
		}
		sqlite3_close(database); 
		return flag;
	}@catch (NSException *e) {
		sqlite3_close(database); 
		NSLog(@"%@",[e description]);
		[e release];
		return flag;	
	}
	//sqlite3_close(database); 
	return flag;	
	
}


- (BOOL)insertRecord:(DatabaseBean *)dataObj{
	@try{
		sqlite3_stmt *stmt;
		const char *query = "insert into LoginTable (email,username,password) values(?,?,?)";
		[self openCreateDatabase];
		if (sqlite3_prepare_v2(database, query, -1, &stmt, NULL) == SQLITE_OK &&
			sqlite3_bind_text(stmt, 1, [[dataObj emailId] UTF8String], -1, NULL) == SQLITE_OK &&
			sqlite3_bind_text(stmt, 2, [[dataObj userNameStr] UTF8String], -1, NULL) == SQLITE_OK && 
			sqlite3_bind_text(stmt, 3, [[dataObj passwordStr] UTF8String], -1, NULL) == SQLITE_OK) {

			int ret = sqlite3_step(stmt);
			if (ret == SQLITE_DONE) {
				sqlite3_finalize(stmt);
				NSLog(@"Done successfully");
				sqlite3_close(database); 
				[dataObj release];
				return YES;
			}
		}
	}@catch(NSException *e){
		sqlite3_close(database); 
		[dataObj release]; 
		NSLog(@"%@",[e description]);
		NSLog(@"Error");
	}
	sqlite3_close(database); 
	[dataObj release];
	return NO;	
	
}

-(void) openCreateDatabase {
	@try{
		databasePath=[self dataFilePath];
		[self createEditableCopyOfDatabaseIfNeeded];
		if (sqlite3_open([databasePath UTF8String], &database) != SQLITE_OK) { 
			sqlite3_close(database);
			[databasePath release];
			NSAssert(0, @"Failed to open database");
		}
	}@catch (NSException *e) {
		NSLog(@"%@",[e description]);
		[databasePath release];
		[e release];
	}
}

// Creates a writable copy of the bundled default database in the application Documents directory.
- (void)createEditableCopyOfDatabaseIfNeeded {
	@try{
		BOOL success;
		NSFileManager *fileManager = [NSFileManager defaultManager];
		NSError *error;
		NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
		NSString *documentsDirectory = [paths objectAtIndex:0];
		NSString *writableDBPath = [documentsDirectory stringByAppendingPathComponent:dbName];
		success = [fileManager fileExistsAtPath:writableDBPath];
		if (success) return;
		// The writable database does not exist, so copy the default to the appropriate location.
		NSLog(@"database not exist, therefore create here...");
		NSString *defaultDBPath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:dbName];
		success = [fileManager copyItemAtPath:defaultDBPath toPath:writableDBPath error:&error];
		if (!success) {
			NSAssert1(0, @"Failed to create writable database file with message '%@'.", [error localizedDescription]);
		}		
	}@catch (NSException *e) {
		NSLog(@"%@",[e description]);
		[e release];
	}
    // First, test for existence.
 }

// Returns Database file path
- (NSString *) dataFilePath {
	@try{
		// Get the path to the documents directory and append the databaseName
		NSArray *documentPaths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
		NSString *documentsDir = [documentPaths objectAtIndex:0];
		databasePath = [documentsDir stringByAppendingPathComponent:dbName];
		return databasePath;		
	}@catch (NSException *e) {
		NSLog(@"%@",[e description]);
		[e release];
	}
	return nil;
}
@end

