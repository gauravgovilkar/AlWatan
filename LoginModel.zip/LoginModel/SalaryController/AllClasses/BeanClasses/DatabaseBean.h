//
//  DatabaseBean.h
//  SalaryController
//
//  Created by freedom passion on 19/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DatabaseBean : UIViewController{
    
    NSString *emailId;
    NSString *userNameStr;
    NSString *passwordStr;
    
}
@property(nonatomic,retain)NSString *emailId;
@property(nonatomic,retain)NSString *userNameStr;
@property(nonatomic,retain)NSString *passwordStr;
@end
