#import "BusyAgent.h"
#define DegreesToRadians(d) ((d) * M_PI / 180.0)

static BusyAgent* agent;

@implementation BusyAgent
- (id)init{
	return nil;
}

- (id)myinit{
	[[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
	if( (self = [super init])){
        
        [[NSNotificationCenter defaultCenter] addObserver:self 
        selector:@selector(changeorientation) 
        name:@"changeorentation" 
        object:nil];
        
        
        [[NSNotificationCenter defaultCenter] addObserver:self 
                 selector:@selector(inotherDirection) 
                 name:@"changeorentation1" 
                 object:nil];
        
		busyCount = 0;
		UIWindow* keywindow = [[UIApplication sharedApplication] keyWindow];
		view = [[UIView alloc] initWithFrame:[keywindow frame]];
		view.backgroundColor = [UIColor blackColor];
		view.alpha = 0.50;
		wait = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
		wait.hidesWhenStopped = NO;
		wait.center = view.center;

		busyLabel = [[UILabel alloc] initWithFrame:CGRectMake(wait.frame.origin.x-20,wait.frame.origin.y-60,175,150)];
		
		//busyLabel.transform = CGAffineTransformMakeRotation(M_PI);

        [view addSubview:wait];
		[wait startAnimating];
		
		return self;
	}
	
	return nil;
}

-(void)progressBar{
    
    
//    UIView *view1=[[UIView alloc] initWithFrame:CGRectMake(340, 500,50 ,500)];
//    view1.backgroundColor=[UIColor colorWithRed:51.0/255.0 green:94.0/255.0 blue:133.0/255.0 alpha:0.96];
    view.alpha = 0.90;
    
    progressViewScreen = [[PDColoredProgressView alloc] initWithProgressViewStyle: UIProgressViewStyleDefault];
     progressViewScreen.frame=CGRectMake(300, 510, 350, 18);
    [progressViewScreen setTintColor:[UIColor colorWithRed: 91.0/255.0 green: 166.0/255.0 blue: 238.0/255.0 alpha: 1]];
    CGAffineTransform transform = CGAffineTransformMake(1, 0, 0, -1, 0, progressViewScreen.frame.size.height); // Flip view vertically
    transform =CGAffineTransformMakeRotation(DegreesToRadians(270));
    progressViewScreen.transform = transform;
    //[view1 addSubview:progressViewScreen];
    
    [view addSubview:progressViewScreen];

    CGAffineTransform transform1 = CGAffineTransformMake(1, 0, 0, -1, 0, busyLabel.frame.size.height); // Flip view vertically
    transform1 =CGAffineTransformMakeRotation(DegreesToRadians(270));
    busyLabel.transform = transform1;
    
    busyLabel.textColor = [UIColor whiteColor];
    busyLabel.backgroundColor = [UIColor clearColor];
    busyLabel.shadowColor = [UIColor blackColor];
    busyLabel.textAlignment = UITextAlignmentCenter;
    busyLabel.text = @"Sync in progress....";
    busyLabel.font = [UIFont fontWithName:@"Helvetica" size:20.0];
    [view addSubview:busyLabel];
    
    
}

-(void)changeorientation{
   
   busyLabel.frame= CGRectMake(170,420,300,200);
   CGAffineTransform transform = CGAffineTransformMake(1, 0, 0, -1, 0, busyLabel.frame.size.height); // Flip view vertically
   transform =CGAffineTransformMakeRotation(DegreesToRadians(90));
   busyLabel.transform = transform;
   
   progressViewScreen.frame=CGRectMake(250, 340, 18, 350);
   CGAffineTransform transform1 = CGAffineTransformMake(1, 0, 0, -1, 0, progressViewScreen.frame.size.height); // Flip view vertically
   transform1 =CGAffineTransformMakeRotation(DegreesToRadians(90));
   progressViewScreen.transform = transform1;
   
   
   
   
}

-(void)inotherDirection{
    
    busyLabel.frame = CGRectMake(350,350,200,300);
    CGAffineTransform transform = CGAffineTransformMake(1, 0, 0, -1, 0, busyLabel.frame.size.height); // Flip view vertically
    transform =CGAffineTransformMakeRotation(DegreesToRadians(270));
    busyLabel.transform = transform;
    
    
    progressViewScreen.frame=CGRectMake(500, 330, 18, 350);
    CGAffineTransform transform1 = CGAffineTransformMake(1, 0, 0, -1, 0, progressViewScreen.frame.size.height); // Flip view vertically
    transform1 =CGAffineTransformMakeRotation(DegreesToRadians(270));
    progressViewScreen.transform = transform1;
    
    
}

-(void)inprogress:(int)count val:(int)value{
    
    
    [progressViewScreen setProgress:(1.0/count * value)];
    
    
}


- (void) makeBusy:(BOOL)yesOrno showBusyIndicator:(BOOL)showIndicatorYesNo{
	if(showIndicatorYesNo){
		[wait setHidden:NO];
		[busyLabel setHidden:NO];
	}else{
		[wait setHidden:YES];
        [busyLabel setHidden:YES];
        busyLabel.text=@"";
        progressViewScreen.progress=0.0;
        [progressViewScreen removeFromSuperview];

        
	}
	if(yesOrno){
		busyCount++;
	}else {
		busyCount--;
		if(busyCount<0){
			busyCount = 0;
		}
	}
	
	if(busyCount == 1){
		[[[UIApplication sharedApplication] keyWindow] addSubview:view];
		[[[UIApplication sharedApplication] keyWindow] bringSubviewToFront:view];
	}else if(busyCount == 0) {
		[view removeFromSuperview];
	}else {
		[[[UIApplication sharedApplication] keyWindow] bringSubviewToFront:view];
	}

}

- (void) queueBusy{
	[self makeBusy:YES showBusyIndicator:YES];
}
- (void) dequeueBusy{
	[self makeBusy:NO showBusyIndicator:NO];
}


- (void) forceRemoveBusyState{
	busyCount = 0;
    	[view removeFromSuperview];
}

+ (BusyAgent*)defaultAgent{
	if(!agent){
		agent =[[BusyAgent alloc] myinit];
	}
	return agent;
}

- (void)dealloc{
	[view release];
	[wait release];
	[busyLabel release];
	[super dealloc];
}
@end
